wp2syslog
=========

It keeps track of wordpress's events and log them to syslog.